﻿namespace CSharpSample
{
    partial class FormServicos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormServicos));
            this.txtSite = new System.Windows.Forms.TextBox();
            this.txtUsuario = new System.Windows.Forms.TextBox();
            this.txtSenha = new System.Windows.Forms.TextBox();
            this.lblSite = new System.Windows.Forms.Label();
            this.lblUsuario = new System.Windows.Forms.Label();
            this.lblSenha = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsbNovo = new System.Windows.Forms.ToolStripButton();
            this.tsbCancelar = new System.Windows.Forms.ToolStripButton();
            this.tsbAdicionar = new System.Windows.Forms.ToolStripButton();
            this.tsbExcluir = new System.Windows.Forms.ToolStripButton();
            this.tsbAtualizar = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.lvlServico = new System.Windows.Forms.Label();
            this.txtNomeServico = new System.Windows.Forms.TextBox();
            this.tblServicosBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dBGerenciadorDataSet = new CSharpSample.DBGerenciadorDataSet();
            this.tblServicosTableAdapter = new CSharpSample.DBGerenciadorDataSetTableAdapters.tblServicosTableAdapter();
            this.chkVizualizar = new System.Windows.Forms.CheckBox();
            this.cboServicos = new System.Windows.Forms.ComboBox();
            this.radFacebook = new System.Windows.Forms.RadioButton();
            this.radMercadoLivre = new System.Windows.Forms.RadioButton();
            this.radOutros = new System.Windows.Forms.RadioButton();
            this.btnCriar = new System.Windows.Forms.Button();
            this.btnLogar = new System.Windows.Forms.Button();
            this.radFatecOnTheHub = new System.Windows.Forms.RadioButton();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copiarUsuarioToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarSenhaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copiarSiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblServicosBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBGerenciadorDataSet)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSite
            // 
            this.txtSite.Location = new System.Drawing.Point(15, 167);
            this.txtSite.Name = "txtSite";
            this.txtSite.Size = new System.Drawing.Size(288, 20);
            this.txtSite.TabIndex = 4;
            // 
            // txtUsuario
            // 
            this.txtUsuario.Location = new System.Drawing.Point(15, 129);
            this.txtUsuario.Name = "txtUsuario";
            this.txtUsuario.Size = new System.Drawing.Size(162, 20);
            this.txtUsuario.TabIndex = 2;
            // 
            // txtSenha
            // 
            this.txtSenha.Location = new System.Drawing.Point(183, 129);
            this.txtSenha.Name = "txtSenha";
            this.txtSenha.PasswordChar = '●';
            this.txtSenha.Size = new System.Drawing.Size(104, 20);
            this.txtSenha.TabIndex = 3;
            // 
            // lblSite
            // 
            this.lblSite.AutoSize = true;
            this.lblSite.Location = new System.Drawing.Point(12, 151);
            this.lblSite.Name = "lblSite";
            this.lblSite.Size = new System.Drawing.Size(28, 13);
            this.lblSite.TabIndex = 10;
            this.lblSite.Text = "Site:";
            // 
            // lblUsuario
            // 
            this.lblUsuario.AutoSize = true;
            this.lblUsuario.Location = new System.Drawing.Point(12, 113);
            this.lblUsuario.Name = "lblUsuario";
            this.lblUsuario.Size = new System.Drawing.Size(46, 13);
            this.lblUsuario.TabIndex = 11;
            this.lblUsuario.Text = "Usuario:";
            // 
            // lblSenha
            // 
            this.lblSenha.AutoSize = true;
            this.lblSenha.Location = new System.Drawing.Point(180, 113);
            this.lblSenha.Name = "lblSenha";
            this.lblSenha.Size = new System.Drawing.Size(41, 13);
            this.lblSenha.TabIndex = 12;
            this.lblSenha.Text = "Senha:";
            // 
            // toolStrip1
            // 
            this.toolStrip1.BackColor = System.Drawing.Color.Transparent;
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbNovo,
            this.tsbCancelar,
            this.tsbAdicionar,
            this.tsbExcluir,
            this.tsbAtualizar,
            this.toolStripSeparator1});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(396, 25);
            this.toolStrip1.TabIndex = 13;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsbNovo
            // 
            this.tsbNovo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbNovo.Image = ((System.Drawing.Image)(resources.GetObject("tsbNovo.Image")));
            this.tsbNovo.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbNovo.Name = "tsbNovo";
            this.tsbNovo.Size = new System.Drawing.Size(23, 22);
            this.tsbNovo.Text = "Novo";
            this.tsbNovo.Click += new System.EventHandler(this.tsbNovo_Click);
            // 
            // tsbCancelar
            // 
            this.tsbCancelar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbCancelar.Image = ((System.Drawing.Image)(resources.GetObject("tsbCancelar.Image")));
            this.tsbCancelar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbCancelar.Name = "tsbCancelar";
            this.tsbCancelar.Size = new System.Drawing.Size(23, 22);
            this.tsbCancelar.Text = "Cancelar";
            this.tsbCancelar.Click += new System.EventHandler(this.tsbCancelar_Click);
            // 
            // tsbAdicionar
            // 
            this.tsbAdicionar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAdicionar.Image = ((System.Drawing.Image)(resources.GetObject("tsbAdicionar.Image")));
            this.tsbAdicionar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAdicionar.Name = "tsbAdicionar";
            this.tsbAdicionar.Size = new System.Drawing.Size(23, 22);
            this.tsbAdicionar.Text = "Adicionar";
            this.tsbAdicionar.Click += new System.EventHandler(this.tsbAdicionar_Click);
            // 
            // tsbExcluir
            // 
            this.tsbExcluir.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbExcluir.Image = ((System.Drawing.Image)(resources.GetObject("tsbExcluir.Image")));
            this.tsbExcluir.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbExcluir.Name = "tsbExcluir";
            this.tsbExcluir.Size = new System.Drawing.Size(23, 22);
            this.tsbExcluir.Text = "Excluir";
            this.tsbExcluir.Click += new System.EventHandler(this.tsbExcluir_Click);
            // 
            // tsbAtualizar
            // 
            this.tsbAtualizar.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.tsbAtualizar.Image = ((System.Drawing.Image)(resources.GetObject("tsbAtualizar.Image")));
            this.tsbAtualizar.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsbAtualizar.Name = "tsbAtualizar";
            this.tsbAtualizar.Size = new System.Drawing.Size(23, 22);
            this.tsbAtualizar.Text = "Atualizar";
            this.tsbAtualizar.Click += new System.EventHandler(this.tsbAtualizar_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // lvlServico
            // 
            this.lvlServico.AutoSize = true;
            this.lvlServico.Location = new System.Drawing.Point(12, 74);
            this.lvlServico.Name = "lvlServico";
            this.lvlServico.Size = new System.Drawing.Size(46, 13);
            this.lvlServico.TabIndex = 14;
            this.lvlServico.Text = "Serviço:";
            // 
            // txtNomeServico
            // 
            this.txtNomeServico.Location = new System.Drawing.Point(15, 90);
            this.txtNomeServico.Name = "txtNomeServico";
            this.txtNomeServico.Size = new System.Drawing.Size(162, 20);
            this.txtNomeServico.TabIndex = 1;
            // 
            // tblServicosBindingSource
            // 
            this.tblServicosBindingSource.DataMember = "tblServicos";
            this.tblServicosBindingSource.DataSource = this.dBGerenciadorDataSet;
            // 
            // dBGerenciadorDataSet
            // 
            this.dBGerenciadorDataSet.DataSetName = "DBGerenciadorDataSet";
            this.dBGerenciadorDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tblServicosTableAdapter
            // 
            this.tblServicosTableAdapter.ClearBeforeFill = true;
            // 
            // chkVizualizar
            // 
            this.chkVizualizar.AutoSize = true;
            this.chkVizualizar.Location = new System.Drawing.Point(294, 131);
            this.chkVizualizar.Name = "chkVizualizar";
            this.chkVizualizar.Size = new System.Drawing.Size(70, 17);
            this.chkVizualizar.TabIndex = 17;
            this.chkVizualizar.Text = "Visualizar";
            this.chkVizualizar.UseVisualStyleBackColor = true;
            this.chkVizualizar.CheckedChanged += new System.EventHandler(this.chkVizualizar_CheckedChanged);
            // 
            // cboServicos
            // 
            this.cboServicos.FormattingEnabled = true;
            this.cboServicos.Location = new System.Drawing.Point(15, 50);
            this.cboServicos.Name = "cboServicos";
            this.cboServicos.Size = new System.Drawing.Size(121, 21);
            this.cboServicos.TabIndex = 18;
            this.cboServicos.SelectedIndexChanged += new System.EventHandler(this.cboServicos_SelectedIndexChanged);
            // 
            // radFacebook
            // 
            this.radFacebook.AutoSize = true;
            this.radFacebook.Location = new System.Drawing.Point(12, 196);
            this.radFacebook.Name = "radFacebook";
            this.radFacebook.Size = new System.Drawing.Size(73, 17);
            this.radFacebook.TabIndex = 19;
            this.radFacebook.TabStop = true;
            this.radFacebook.Text = "Facebook";
            this.radFacebook.UseVisualStyleBackColor = true;
            // 
            // radMercadoLivre
            // 
            this.radMercadoLivre.AutoSize = true;
            this.radMercadoLivre.Location = new System.Drawing.Point(91, 193);
            this.radMercadoLivre.Name = "radMercadoLivre";
            this.radMercadoLivre.Size = new System.Drawing.Size(93, 17);
            this.radMercadoLivre.TabIndex = 20;
            this.radMercadoLivre.TabStop = true;
            this.radMercadoLivre.Text = "Mercado Livre";
            this.radMercadoLivre.UseVisualStyleBackColor = true;
            // 
            // radOutros
            // 
            this.radOutros.AutoSize = true;
            this.radOutros.Location = new System.Drawing.Point(15, 228);
            this.radOutros.Name = "radOutros";
            this.radOutros.Size = new System.Drawing.Size(56, 17);
            this.radOutros.TabIndex = 21;
            this.radOutros.TabStop = true;
            this.radOutros.Text = "Outros";
            this.radOutros.UseVisualStyleBackColor = true;
            // 
            // btnCriar
            // 
            this.btnCriar.Location = new System.Drawing.Point(309, 167);
            this.btnCriar.Name = "btnCriar";
            this.btnCriar.Size = new System.Drawing.Size(75, 23);
            this.btnCriar.TabIndex = 24;
            this.btnCriar.Text = "Criar Sessão";
            this.btnCriar.UseVisualStyleBackColor = true;
            this.btnCriar.Click += new System.EventHandler(this.btnCriar_Click);
            // 
            // btnLogar
            // 
            this.btnLogar.Location = new System.Drawing.Point(309, 196);
            this.btnLogar.Name = "btnLogar";
            this.btnLogar.Size = new System.Drawing.Size(75, 23);
            this.btnLogar.TabIndex = 25;
            this.btnLogar.Text = "Logar";
            this.btnLogar.UseVisualStyleBackColor = true;
            this.btnLogar.Click += new System.EventHandler(this.btnLogar_Click);
            // 
            // radFatecOnTheHub
            // 
            this.radFatecOnTheHub.AutoSize = true;
            this.radFatecOnTheHub.Location = new System.Drawing.Point(190, 193);
            this.radFatecOnTheHub.Name = "radFatecOnTheHub";
            this.radFatecOnTheHub.Size = new System.Drawing.Size(108, 17);
            this.radFatecOnTheHub.TabIndex = 26;
            this.radFatecOnTheHub.TabStop = true;
            this.radFatecOnTheHub.Text = "Fatec OnTheHub";
            this.radFatecOnTheHub.UseVisualStyleBackColor = true;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copiarUsuarioToolStripMenuItem,
            this.copiarSenhaToolStripMenuItem,
            this.copiarSiteToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(153, 92);
            // 
            // copiarUsuarioToolStripMenuItem
            // 
            this.copiarUsuarioToolStripMenuItem.Name = "copiarUsuarioToolStripMenuItem";
            this.copiarUsuarioToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copiarUsuarioToolStripMenuItem.Text = "Copiar Usuario";
            this.copiarUsuarioToolStripMenuItem.Click += new System.EventHandler(this.copiarUsuarioToolStripMenuItem_Click);
            // 
            // copiarSenhaToolStripMenuItem
            // 
            this.copiarSenhaToolStripMenuItem.Name = "copiarSenhaToolStripMenuItem";
            this.copiarSenhaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copiarSenhaToolStripMenuItem.Text = "Copiar Senha";
            this.copiarSenhaToolStripMenuItem.Click += new System.EventHandler(this.copiarSenhaToolStripMenuItem_Click);
            // 
            // copiarSiteToolStripMenuItem
            // 
            this.copiarSiteToolStripMenuItem.Name = "copiarSiteToolStripMenuItem";
            this.copiarSiteToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.copiarSiteToolStripMenuItem.Text = "Copiar Site";
            this.copiarSiteToolStripMenuItem.Click += new System.EventHandler(this.copiarSiteToolStripMenuItem_Click);
            // 
            // FormServicos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(396, 257);
            this.ContextMenuStrip = this.contextMenuStrip1;
            this.Controls.Add(this.radFatecOnTheHub);
            this.Controls.Add(this.btnLogar);
            this.Controls.Add(this.btnCriar);
            this.Controls.Add(this.radOutros);
            this.Controls.Add(this.radMercadoLivre);
            this.Controls.Add(this.radFacebook);
            this.Controls.Add(this.cboServicos);
            this.Controls.Add(this.chkVizualizar);
            this.Controls.Add(this.txtNomeServico);
            this.Controls.Add(this.lvlServico);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.lblSenha);
            this.Controls.Add(this.lblUsuario);
            this.Controls.Add(this.lblSite);
            this.Controls.Add(this.txtSenha);
            this.Controls.Add(this.txtUsuario);
            this.Controls.Add(this.txtSite);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FormServicos";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Servicos";
            this.Load += new System.EventHandler(this.fmrServicos_Load);
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tblServicosBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dBGerenciadorDataSet)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtSite;
        private System.Windows.Forms.TextBox txtUsuario;
        private System.Windows.Forms.TextBox txtSenha;
        private System.Windows.Forms.Label lblSite;
        private System.Windows.Forms.Label lblUsuario;
        private System.Windows.Forms.Label lblSenha;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsbAdicionar;
        private System.Windows.Forms.ToolStripButton tsbExcluir;
        private System.Windows.Forms.ToolStripButton tsbAtualizar;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.Label lvlServico;
        private System.Windows.Forms.TextBox txtNomeServico;
        private DBGerenciadorDataSet dBGerenciadorDataSet;
        private System.Windows.Forms.BindingSource tblServicosBindingSource;
        private DBGerenciadorDataSetTableAdapters.tblServicosTableAdapter tblServicosTableAdapter;
        private System.Windows.Forms.CheckBox chkVizualizar;
        private System.Windows.Forms.ComboBox cboServicos;
        private System.Windows.Forms.ToolStripButton tsbNovo;
        private System.Windows.Forms.ToolStripButton tsbCancelar;
        private System.Windows.Forms.RadioButton radFacebook;
        private System.Windows.Forms.RadioButton radMercadoLivre;
        private System.Windows.Forms.RadioButton radOutros;
        private System.Windows.Forms.Button btnCriar;
        private System.Windows.Forms.Button btnLogar;
        private System.Windows.Forms.RadioButton radFatecOnTheHub;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copiarUsuarioToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarSenhaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copiarSiteToolStripMenuItem;
    }
}