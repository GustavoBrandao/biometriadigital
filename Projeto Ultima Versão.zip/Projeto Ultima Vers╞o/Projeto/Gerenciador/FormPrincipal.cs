using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using Neurotec.Biometrics;
using Neurotec.Gui;

namespace CSharpSample
{
    public partial class FormPrincipal : Form
	{
		Nffv _engine;
		string _userDatabaseFile;
		UserDatabase _userDB;

		public FormPrincipal(Nffv engine, string userDatabaseFile)
		{

			_engine = engine;

			_userDatabaseFile = userDatabaseFile;
			try
			{
				_userDB = UserDatabase.ReadFromFile(userDatabaseFile);
			}
			catch
			{
				_userDB = new UserDatabase();
			}

			InitializeComponent();
		}

		private void MainForm_Load(object sender, EventArgs e)
		{
            
            foreach (NffvUser engineUser in _engine.Users)
			{
				string id = engineUser.Id.ToString();
				UserRecord userRec = _userDB.Lookup(engineUser.Id);
				if (userRec != null)
				{
					id = userRec.Name;
				}
				lbDatabase.Items.Add(new CData(engineUser, id));

                int x = lbDatabase.Items.Count;
                if (x == 1)
                {
                    btnCadastrar.Visible = false;
                    btnDeletar.Visible = false;
                    btnConfiguracoes.Visible = false;
                    lbDatabase.Visible = false;
                    pbExtractedImage.Visible = false;
                    this.Size = new System.Drawing.Size(155, 239);
                    
                }

            }
			if (lbDatabase.Items.Count > 0)
				lbDatabase.SelectedIndex = 0;
		}

		internal class EnrollmentResult
		{
			public NffvStatus engineStatus;
			public NffvUser engineUser;
		};

		private void doEnroll(object sender, DoWorkEventArgs args)
		{
			EnrollmentResult enrollmentResults = new EnrollmentResult();
			enrollmentResults.engineUser = _engine.Enroll(20000, out enrollmentResults.engineStatus);
			args.Result = enrollmentResults;
		}

		internal class VerificationResult
		{
			public NffvStatus engineStatus;
			public int score;
		};
		private void doVerify(object sender, DoWorkEventArgs args)
		{
			VerificationResult verificationResult = new VerificationResult();
			verificationResult.score = _engine.Verify((NffvUser)args.Argument, 20000, out verificationResult.engineStatus);
			args.Result = verificationResult;
		} // metodo de verifica��o da digital com a database
		private void CancelScanningHandler(object sender, EventArgs e)
		{
			_engine.Cancel();
		} // Metodo de cancelamento de leitura
        private void btnEntrar_Click(object sender, EventArgs e)
        {
            if (lbDatabase.SelectedIndex < 0)
            {
                MessageBox.Show("Selecione o usuario a ser autenticado.");
            }
            else
            {
               try

                {
                   
                     RunWorkerCompletedEventArgs taskResult = BusyForm.RunLongTask("Aguardando a inser��o da Digital ...", new DoWorkEventHandler(doVerify),
                          false, ((CData)lbDatabase.SelectedItem).EngineUser, new EventHandler(CancelScanningHandler));
                      VerificationResult verificationResult = (VerificationResult)taskResult.Result;
                      if (verificationResult.engineStatus == NffvStatus.TemplateCreated)
                      { 
                          if (verificationResult.score > 0)
                          {

                              FormServicos fmrServicos = new FormServicos();
                              fmrServicos.ShowDialog();

                          }
                          else
                          {
                              MessageBox.Show("Digital Invalida!");

                          }
                      }
                      else
                      {
                          MessageBox.Show(string.Format("Verification was not finished. Reason: {0}", verificationResult.engineStatus));
                      }

                } 
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        } // Verifica a digital na database e autentica
        private void btnCadastrar_Click(object sender, EventArgs e)
        {

          int x = lbDatabase.Items.Count;
          if (x == 0)
            {
                
            FormRegistro enrollDlg = new FormRegistro();
            if (enrollDlg.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    RunWorkerCompletedEventArgs taskResult = BusyForm.RunLongTask("Insira A Digital ...", new DoWorkEventHandler(doEnroll),
                        false, null, new EventHandler(CancelScanningHandler));
                    EnrollmentResult enrollmentResult = (EnrollmentResult)taskResult.Result;
                    if (enrollmentResult.engineStatus == NffvStatus.TemplateCreated)
                    {
                        NffvUser engineUser = enrollmentResult.engineUser;
                        string userName = enrollDlg.UserName;
                        if (userName.Length <= 0)
                        {
                            userName = engineUser.Id.ToString();
                        }

                        _userDB.Add(new UserRecord(engineUser.Id, userName));
                        try
                        {
                            _userDB.WriteToFile(_userDatabaseFile); // grava no XML
                        }
                        catch { }

                        pbExtractedImage.Image = engineUser.GetBitmap();
                        lbDatabase.Items.Add(new CData(engineUser, userName)); //grava no banco
                        lbDatabase.SelectedIndex = lbDatabase.Items.Count - 1;
                    }
                    else
                    {
                        NffvStatus engineStatus = enrollmentResult.engineStatus;
                        MessageBox.Show(string.Format("Enrollment was not finished. Reason: {0}", engineStatus));
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
          }
            else
            {
                MessageBox.Show("Digital J� Cadastrada");
            }
        } // Cadastra nova digital
        private void btnDeletar_Click(object sender, EventArgs e)
        {
            if (lbDatabase.SelectedIndex < 0)
            {
                MessageBox.Show("Please select a record from the database.");
            }
            else
            {
                _userDB.Remove(_userDB.Lookup(((CData)lbDatabase.SelectedItem).ID));
                try
                {
                    _userDB.WriteToFile(_userDatabaseFile);
                }
                catch { }

                _engine.Users.RemoveAt(lbDatabase.SelectedIndex);
                lbDatabase.Items.RemoveAt(lbDatabase.SelectedIndex);
                if (lbDatabase.Items.Count > 0)
                    lbDatabase.SelectedIndex = 0;
            }
        } // Deleta digital selecionada
        private void btnConfiguracoes_Click(object sender, EventArgs e)
        {
            FormConfiguracoes settingsForm = new FormConfiguracoes();
            settingsForm.LoadFromEngine(_engine);
            if (settingsForm.ShowDialog() == DialogResult.OK)
            {
                settingsForm.SaveToEngine(_engine);
            }
        } // Configura��es da qualidade do leitor de digital

        private void btnSair_Click(object sender, EventArgs e)
        {
            DialogResult mensagem = MessageBox.Show("Deseja finalizar a aplica��o?", "Encerrar", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2);

            if (mensagem == System.Windows.Forms.DialogResult.Yes)
            {
                this.Close();
            }

        }

    }


    class CData : IDisposable
	{
		private NffvUser _engineUser;
		private Bitmap _image;
		private string _name;

		public CData(NffvUser engineUser, string name)
		{
			_engineUser = engineUser;
			_image = engineUser.GetBitmap();
			_name = name;
		}

		public NffvUser EngineUser
		{
			get
			{
				return _engineUser;
			}
		}

		public Bitmap Image
		{
			get
			{
				return _image;
			}
		}

		public int ID
		{
			get
			{
				return _engineUser.Id;
			}
		}

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				_name = value;
			}
		}

		public override string ToString()
		{
			return Name;
		}

		#region IDisposable Members

		public void Dispose()
		{
			if (_image != null)
			{
				_image.Dispose();
				_image = null;
			}
		}

		#endregion
	}
}
