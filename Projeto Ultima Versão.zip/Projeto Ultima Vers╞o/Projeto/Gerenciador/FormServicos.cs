﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Diagnostics;

namespace CSharpSample
{
    public partial class FormServicos : Form
    {
      public string tipoServico = "";
        public FormServicos()
        {
            InitializeComponent();
           Fillcombo();
           

        }

       

        void Fillcombo()
        {
            cboServicos.Items.Clear();


            strSql = "SELECT NomeServico FROM tblServicos ;";
            sqlCon = new SqlConnection(strCon);
            SqlCommand comando = new SqlCommand(strSql, sqlCon);

            try
            {
                sqlCon.Open();
                SqlDataReader dr = comando.ExecuteReader();
                while (dr.Read())
                    {
                    string sNomeServico = dr.GetValue(0).ToString();
                    cboServicos.Items.Add(sNomeServico);
                    }
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

        } // Metodo De Preenchimento do combobox com nome dos serviços

        SqlConnection sqlCon = null;
        private string strCon = @"Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=DBGerenciador;Data Source=ARDA\SQLEXPRESS01";
        private string strSql = string.Empty;
        
        private void fmrServicos_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'dBGerenciadorDataSet.tblServicos' table. You can move, or remove it, as needed.
            this.tblServicosTableAdapter.Fill(this.dBGerenciadorDataSet.tblServicos);
            tsbNovo.Enabled = true;
            tsbAdicionar.Enabled = false;
            tsbCancelar.Enabled = false;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = false;
            txtUsuario.Enabled = false;
            txtSenha.Enabled = false;
            txtSite.Enabled = false;
            radFacebook.Visible = false;
            radMercadoLivre.Visible = false;
            radFatecOnTheHub.Visible = false;
            radOutros.Visible = false;
            btnLogar.Visible = false;
            btnCriar.Visible = false;
            string path = @"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs";
            File.Delete(path);
        }

        private void tsbAdicionar_Click(object sender, EventArgs e) //Adiciona os dados dos campos no banco de dados
        {
            tipoServico = "";
            if (radFacebook.Checked) { tipoServico = radFacebook.Text; }
            if (radMercadoLivre.Checked) { tipoServico = radMercadoLivre.Text; }
            if (radFatecOnTheHub.Checked) { tipoServico = radFatecOnTheHub.Text; }
            if (radOutros.Checked) { tipoServico = radOutros.Text; }

            strSql = "insert into tblServicos (NomeServico, Usuario, Senha, Site, TipoServico) values (@NomeServico, @Usuario, @Senha, @Site, @TipoServico)";
            sqlCon = new SqlConnection(strCon);
            SqlCommand comando = new SqlCommand(strSql, sqlCon);
            comando.Parameters.Add("@NomeServico", SqlDbType.VarChar).Value = txtNomeServico.Text;
            comando.Parameters.Add("@Usuario", SqlDbType.VarChar).Value =Criptografia.Encrypt(txtUsuario.Text);
            comando.Parameters.Add("@Senha", SqlDbType.VarChar).Value =Criptografia.Encrypt(txtSenha.Text);
            comando.Parameters.Add("@Site", SqlDbType.VarChar).Value = txtSite.Text;
            comando.Parameters.Add("@TipoServico", SqlDbType.VarChar).Value = tipoServico;

            try
            {
                sqlCon.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro Realizado com Sucesso!");
                Fillcombo();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }

            tsbNovo.Enabled = true;
            tsbCancelar.Enabled = false;
            tsbAdicionar.Enabled = false;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;
            txtNomeServico.Clear();
            txtUsuario.Clear();
            txtSenha.Clear();
            txtSite.Clear();
            radFacebook.Visible = false;
            radMercadoLivre.Visible = false;
            radFatecOnTheHub.Visible = false;
            radOutros.Visible = false;
            btnLogar.Visible = false;
            btnCriar.Visible = false;

        }

        private void tsbAtualizar_Click(object sender, EventArgs e)
        {
            strSql = "update tblServicos set NomeServico=@NomeServico, Usuario=@Usuario, Senha=@Senha, Site=@Site where NomeServico=@NomeServicoBuscar";
            sqlCon = new SqlConnection(strCon);
            SqlCommand comando = new SqlCommand(strSql, sqlCon);

            comando.Parameters.Add("@NomeServicoBuscar", SqlDbType.VarChar).Value = cboServicos.Text;

            comando.Parameters.Add("@NomeServico", SqlDbType.VarChar).Value = txtNomeServico.Text;
            comando.Parameters.Add("@Usuario", SqlDbType.VarChar).Value = Criptografia.Encrypt(txtUsuario.Text);
            comando.Parameters.Add("@Senha", SqlDbType.VarChar).Value = Criptografia.Encrypt(txtSenha.Text); ;
            comando.Parameters.Add("@Site", SqlDbType.VarChar).Value = txtSite.Text;

            try
            {

                sqlCon.Open();
                comando.ExecuteNonQuery();
                MessageBox.Show("Cadastro Atualizado!");
            }

            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            
            }

            finally
            {
                sqlCon.Close();
            }

            tsbNovo.Enabled = true;
            tsbAdicionar.Enabled = false;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;
            txtNomeServico.Clear();
            txtUsuario.Clear();
            txtSenha.Clear();
            txtSite.Clear();
            Fillcombo();
        } //Atualiza os dados dos campos no banco de dados

        private void tsbExcluir_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja Realmente Excluir o Serviço?", "Apagar", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.No)
            {
             MessageBox.Show("Operação Cancelada !");
            }

                        
            else
            {
                strSql = "delete from tblServicos where NomeServico=@NomeServicoBuscar";
                sqlCon = new SqlConnection(strCon);
                SqlCommand comando = new SqlCommand(strSql, sqlCon);

                comando.Parameters.Add("@NomeServicoBuscar", SqlDbType.VarChar).Value = cboServicos.Text;
                try
                {
                    sqlCon.Open();
                    comando.ExecuteNonQuery();
                    MessageBox.Show("Serviço Deletado com Sucesso!");
                    Fillcombo();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);

                }

                finally
                {
                    sqlCon.Close();
                }
            }

            tsbNovo.Enabled = true;
            tsbAdicionar.Enabled = false;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;
            txtNomeServico.Clear();
            txtUsuario.Clear();
            txtSenha.Clear();
            txtSite.Clear();
            btnLogar.Visible = false;
            btnCriar.Visible = false;



        } //Exclui os dados dos campos no banco de dados

        private void chkVizualizar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkVizualizar.Checked)
            {
                txtSenha.PasswordChar = '\0';
            }
            else
            {
                txtSenha.PasswordChar = '●';
            }
                
    }

        private void cboServicos_SelectedIndexChanged(object sender, EventArgs e)
        {
            tsbNovo.Enabled = true;
            tsbCancelar.Enabled = false;
            tsbAdicionar.Enabled = false;
            tsbExcluir.Enabled = true;
            tsbAtualizar.Enabled = true;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;

            strSql = "SELECT * FROM tblServicos WHERE NomeServico= '" + cboServicos.Text + "' ;";
            sqlCon = new SqlConnection(strCon);
            SqlCommand comando = new SqlCommand(strSql, sqlCon);

            try
            {
                sqlCon.Open();
                SqlDataReader dr = comando.ExecuteReader();
                while (dr.Read())
                {

                    txtNomeServico.Text = dr.GetValue(1).ToString();
                    txtUsuario.Text = Criptografia.Decrypt(dr.GetValue(2).ToString());
                    txtSenha.Text = Criptografia.Decrypt(dr.GetValue(3).ToString());
                    txtSite.Text = dr.GetValue(4).ToString();
                    tipoServico = dr.GetValue(5).ToString();
                    
                }

                if (tipoServico == "Facebook" || tipoServico == "Mercado Livre" || tipoServico == "Fatec OnTheHub")
                {
                    btnLogar.Visible = true;
                    btnCriar.Visible = true;
                }
                else
                {
                    btnLogar.Visible = false;
                    btnCriar.Visible = false;
                }

            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                sqlCon.Close();
            }
        }

        private void tsbNovo_Click(object sender, EventArgs e)
        {
            tsbNovo.Enabled = false;
            tsbCancelar.Enabled = true;
            tsbAdicionar.Enabled = true;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = false;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;
            txtNomeServico.Clear();
            txtUsuario.Clear();
            txtSenha.Clear();
            txtSite.Clear();
            radFacebook.Visible = true;
            radMercadoLivre.Visible = true;
            radFatecOnTheHub.Visible = true;
            radOutros.Visible = true;
            btnLogar.Visible = false;
            btnCriar.Visible = false;

        }

        private void tsbCancelar_Click(object sender, EventArgs e)
        {

            tsbNovo.Enabled = true;
            tsbAdicionar.Enabled = false;
            tsbExcluir.Enabled = false;
            tsbAtualizar.Enabled = false;
            cboServicos.Enabled = true;
            txtNomeServico.Enabled = true;
            txtUsuario.Enabled = true;
            txtSenha.Enabled = true;
            txtSite.Enabled = true;
            txtNomeServico.Clear();
            txtUsuario.Clear();
            txtSenha.Clear();
            txtSite.Clear();
            radFacebook.Visible = false;
            radMercadoLivre.Visible = false;
            radFatecOnTheHub.Visible = false;
            radOutros.Visible = false;
            btnLogar.Visible = false;
            btnCriar.Visible = false;

        }

        private void btnCriar_Click(object sender, EventArgs e)
        {
            if (tipoServico == "Facebook")
            {
                StreamWriter writer = new StreamWriter(@"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs", true);
                using (writer)
                {
                    // Escreve uma nova linha no final do arquivo
                    writer.WriteLine("Dim IE");
                    writer.WriteLine("Set IE = CreateObject(\"InternetExplorer.Application\")");
                    writer.WriteLine("IE.Visible = 1");
                    writer.WriteLine("IE.navigate \"" + txtSite.Text + "\"");
                    writer.WriteLine("Do While (IE.Busy)");
                    writer.WriteLine("WScript.Sleep 10");
                    writer.WriteLine("Loop");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"email\")");
                    writer.WriteLine("Helem.Value = \"" + txtUsuario.Text + "\"");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"pass\")");
                    writer.WriteLine("Helem.Value = \"" + txtSenha.Text + "\"");
                    writer.WriteLine("Set Helem = IE.document.Forms(0)");
                    writer.WriteLine("Helem.Submit");

                }
            }

            if ( tipoServico == "Mercado Livre")
            {
                StreamWriter writer = new StreamWriter(@"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs", true);
                using (writer)
                {
                    // Escreve uma nova linha no final do arquivo
                    writer.WriteLine("Dim IE");
                    writer.WriteLine("Set IE = CreateObject(\"InternetExplorer.Application\")");
                    writer.WriteLine("IE.Visible = 1");
                    writer.WriteLine("IE.navigate \"" + txtSite.Text + "\"");
                    writer.WriteLine("Do While (IE.Busy)");
                    writer.WriteLine("WScript.Sleep 10");
                    writer.WriteLine("Loop");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"user_id\")");
                    writer.WriteLine("Helem.Value = \"" + txtUsuario.Text + "\"");
                    writer.WriteLine("IE.document.Forms(0).Submit");
                    writer.WriteLine("WScript.Sleep 5000");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"password\")");
                    writer.WriteLine("Helem.Value = \"" + txtSenha.Text + "\"");
                    writer.WriteLine("Set Helem = IE.document.Forms(0)");
                    writer.WriteLine("Helem.Submit");

                }
            }

            if (tipoServico == "Fatec OnTheHub")
            {
                StreamWriter writer = new StreamWriter(@"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs", true);
                using (writer)
                {
                    // Escreve uma nova linha no final do arquivo
                    writer.WriteLine("Dim IE");
                    writer.WriteLine("Set IE = CreateObject(\"InternetExplorer.Application\")");
                    writer.WriteLine("IE.Visible = 1");
                    writer.WriteLine("IE.navigate \"" + txtSite.Text + "\"");
                    writer.WriteLine("Do While (IE.Busy)");
                    writer.WriteLine("WScript.Sleep 10");
                    writer.WriteLine("Loop");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"ctl00_cpContent_txtUserName\")");
                    writer.WriteLine("Helem.Value = \"" + txtUsuario.Text + "\"");
                    writer.WriteLine("Set Helem = IE.document.getElementByID(\"ctl00_cpContent_txtPassword\")");
                    writer.WriteLine("Helem.Value = \"" + txtSenha.Text + "\"");
                    writer.WriteLine("Set Helem = IE.document.Forms(0)");
                    writer.WriteLine("IE.Document.all.Item(\"ctl00$cpContent$btnSignIn\").Click");
                }
            }

        }
        private void btnLogar_Click(object sender, EventArgs e)
        {
            Process scriptProc = new Process();
            scriptProc.StartInfo.FileName = @"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs";
            scriptProc.Start();
            scriptProc.WaitForExit();
            scriptProc.Close();

            System.Threading.Thread.Sleep(5000);
            string path = @"C:\Users\Gustavo\OneDrive\TCC\bin\win32_x86\Script\script.vbs";

            File.Delete(path);



        }

        private void copiarUsuarioToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtUsuario.Text);
        }

        private void copiarSenhaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtSenha.Text);
        }

        private void copiarSiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetDataObject(txtSite.Text);
        }
    }
    
}

